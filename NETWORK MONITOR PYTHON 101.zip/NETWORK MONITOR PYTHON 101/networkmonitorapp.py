

import tkinter as tk
from tkinter import ttk, messagebox
import psutil
import time
import threading
import socket
import requests
import csv
import os


UPDATE_INTERVAL_MS = 1000   # UI update interval in milliseconds (1000 ms = 1s)
IP_GEOLOCATION_URL = "http://ip-api.com/json/"   # returns JSON with lat/lon (no API key)
RECORD_CSV = "gps_records.csv"
# ------------

def is_internet_up(timeout=1.0):
    """Quick check for internet connectivity via socket to DNS port."""
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=timeout)
        return True
    except OSError:
        return False

def guess_network_type():
    """
    Heuristic detection of connection type:
      - looks at interface names and active NICs
      - returns "Wi-Fi", "Mobile", "Wired", or "Offline / Unknown"
    This is heuristic — interface names vary by OS.
    """
    if not is_internet_up(timeout=0.8):
        return "Offline"

    stats = psutil.net_if_stats()
    names = [name.lower() for name, s in stats.items() if s.isup]
    # common patterns
    for name in names:
        if any(token in name for token in ("wi-fi", "wifi", "wlan", "wireless", "wl")):
            return "Wi-Fi"
    for name in names:
        if any(token in name for token in ("wwan", "cell", "mobile", "ppp", "rmnet")):
            return "Mobile Data"
    for name in names:
        if any(token in name for token in ("eth", "en", "lan")):
            return "Wired"
    # fallback: if we have any active interface and internet access
    if names:
        return "Connected"
    return "Offline"

def get_ip_geolocation():
    """Returns a dict with lat/lon/city/region/country or None if fails."""
    try:
        resp = requests.get(IP_GEOLOCATION_URL, timeout=3)
        if resp.status_code == 200:
            data = resp.json()
            if data.get("status") == "success":
                return {
                    "lat": data.get("lat"),
                    "lon": data.get("lon"),
                    "city": data.get("city"),
                    "region": data.get("regionName"),
                    "country": data.get("country"),
                    "ip": data.get("query")
                }
    except Exception:
        pass
    return None

class NetworkMonitorApp:
    def __init__(self, root):
        self.root = root
        root.title("Network Clock Monitor")
        root.configure(bg="black")
        root.geometry("520x320")
        root.resizable(False, False)

        # Fonts & style
        self.big_font = ("Segoe UI", 40, "bold")
        self.medium_font = ("Segoe UI", 16)
        self.small_font = ("Segoe UI", 12)
        self.accent = "#00FFAA"  # greenish accent for digital look

        # UI layout (clock-style)
        self.frame = tk.Frame(root, bg="black", padx=12, pady=12)
        self.frame.pack(fill="both", expand=True)

        # Network status (top)
        self.status_label = tk.Label(self.frame, text="Network: ...", fg=self.accent, bg="black", font=self.medium_font)
        self.status_label.pack(anchor="w")

        # Big row: download and upload (side-by-side)
        self.big_row = tk.Frame(self.frame, bg="black")
        self.big_row.pack(fill="x", pady=(8, 6))

        self.down_frame = tk.Frame(self.big_row, bg="black")
        self.down_frame.pack(side="left", expand=True, fill="both", padx=6)
        self.down_title = tk.Label(self.down_frame, text="Download", fg="white", bg="black", font=self.small_font)
        self.down_title.pack(anchor="center")
        self.down_value = tk.Label(self.down_frame, text="0.00 Mbps", fg=self.accent, bg="black", font=self.big_font)
        self.down_value.pack(anchor="center")

        self.up_frame = tk.Frame(self.big_row, bg="black")
        self.up_frame.pack(side="left", expand=True, fill="both", padx=6)
        self.up_title = tk.Label(self.up_frame, text="Upload", fg="white", bg="black", font=self.small_font)
        self.up_title.pack(anchor="center")
        self.up_value = tk.Label(self.up_frame, text="0.00 Mbps", fg=self.accent, bg="black", font=self.big_font)
        self.up_value.pack(anchor="center")

        # small row: timestamp & gps
        self.bottom_row = tk.Frame(self.frame, bg="black")
        self.bottom_row.pack(fill="x", pady=(8,0))

        self.time_label = tk.Label(self.bottom_row, text="", fg="white", bg="black", font=self.medium_font)
        self.time_label.pack(side="left", padx=(0,10))

        self.gps_label = tk.Label(self.bottom_row, text="GPS: locating...", fg="white", bg="black", font=self.small_font)
        self.gps_label.pack(side="left", padx=(10,0))

        # Record GPS button
        self.record_button = tk.Button(self.frame, text="Record GPS", command=self.record_gps, font=self.small_font)
        self.record_button.pack(anchor="e", pady=(12,0))

        # Internal state for measuring throughput
        self.last_counters = psutil.net_io_counters(pernic=False)
        self.last_time = time.time()

        # Start periodic update
        self.update_loop()

    def human_mbps(self, bytes_per_sec):
        """Convert bytes/s to Mbps (megabits per second) with two decimals."""
        if bytes_per_sec is None:
            return "0.00"
        # bytes/s -> bits/s -> megabits/s
        mbps = (bytes_per_sec * 8) / 1_000_000
        return f"{mbps:0.2f}"

    def update_loop(self):
        """Main UI update that runs on Tkinter event loop."""
        now = time.time()
        # get counters and compute rates over the last interval
        curr_counters = psutil.net_io_counters(pernic=False)
        dt = now - self.last_time if self.last_time else 1.0
        if dt <= 0:
            dt = 1.0
        bytes_recv = curr_counters.bytes_recv - self.last_counters.bytes_recv
        bytes_sent = curr_counters.bytes_sent - self.last_counters.bytes_sent
        down_bps = bytes_recv / dt
        up_bps = bytes_sent / dt

        # update stored counters
        self.last_counters = curr_counters
        self.last_time = now

        # update UI values
        down_text = f"{self.human_mbps(down_bps)} Mbps"
        up_text = f"{self.human_mbps(up_bps)} Mbps"
        self.down_value.config(text=down_text)
        self.up_value.config(text=up_text)

        # network type / status (non-blocking quick check)
        # We'll call is_internet_up which is quick; if you want to avoid any network call,
        # comment this out and default to 'Unknown'.
        try:
            net_type = guess_network_type()
        except Exception:
            net_type = "Unknown"
        self.status_label.config(text=f"Network: {net_type}")

        # time
        timestr = time.strftime("%H:%M:%S")
        self.time_label.config(text=timestr)

        # update GPS display less frequently (every 10 s) to avoid web requests each second.
        # We'll use the current second to decide when to refresh GPS cached value.
        sec = int(now) % 10
        if not hasattr(self, "_last_geo_time"):
            self._last_geo_time = 0
            self._geo_info = None

        if time.time() - self._last_geo_time > 9:
            # fetch in a separate thread to avoid UI freezing
            threading.Thread(target=self._fetch_geo_async, daemon=True).start()

        # update gps label from cached info
        if self._geo_info:
            g = self._geo_info
            gps_text = f"GPS: {g.get('lat'):.4f}, {g.get('lon'):.4f} ({g.get('city')}, {g.get('country')})"
        else:
            gps_text = "GPS: locating..."
        self.gps_label.config(text=gps_text)

        # schedule next update
        self.root.after(UPDATE_INTERVAL_MS, self.update_loop)

    def _fetch_geo_async(self):
        """Fetch geo info and store it in _geo_info. Runs in separate thread."""
        info = get_ip_geolocation()
        if info:
            self._geo_info = info
            self._last_geo_time = time.time()
        else:
            # if fail, keep previous but update timestamp so we don't hammer the endpoint
            self._last_geo_time = time.time()

    def record_gps(self):
        """Record the current GPS position to a CSV file."""
        if not getattr(self, "_geo_info", None):
            messagebox.showwarning("GPS not ready", "GPS position not yet available. Try again in a few seconds.")
            return
        g = self._geo_info
        exists = os.path.exists(RECORD_CSV)
        try:
            with open(RECORD_CSV, "a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                if not exists:
                    writer.writerow(["timestamp_utc", "ip", "lat", "lon", "city", "region", "country"])
                writer.writerow([time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), g.get("ip"), g.get("lat"), g.get("lon"), g.get("city"), g.get("region"), g.get("country")])
            messagebox.showinfo("Recorded", f"GPS record saved to {RECORD_CSV}")
        except Exception as e:
            messagebox.showerror("Error", f"Could not write file: {e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = NetworkMonitorApp(root)
    root.mainloop()
